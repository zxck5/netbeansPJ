package utilities;

public enum Currency {
	CAD,
	USD
}
